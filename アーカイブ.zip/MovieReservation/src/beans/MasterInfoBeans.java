package beans;

public class MasterInfoBeans {
	private String masterCode;

	public String getMasterCode() {
		return masterCode;
	}

	public void setMasterCode(String masterCode) {
		this.masterCode = masterCode;
	}
}