package beans;

public class TimesortBeans {
	private String theaterNumber;
	public String getTheaterNumber() {
		return theaterNumber;
	}
	public void setTheaterNumber(String theaterNumber) {
		this.theaterNumber = theaterNumber;
	}
	private int hour;
	private int minute;
	private int totalminute;
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public int getTotalminute() {
		return totalminute;
	}
	public void setTotalminute(int totalminute) {
		this.totalminute = totalminute;
	}
	
}
